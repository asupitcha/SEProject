import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class LogInView extends JFrame{
	private JButton logIn;
	private JButton cancel;
	private JTextField id;
	private JTextField passWord;

	public LogInView() throws IOException  {
	
		// i have set size of JFrame to size of my image there for image will cover all the area of JFrame
		setPreferredSize(new Dimension(700, 400));
		 
		// read image file in my HardDisk using imageIO and assign it to buffered image reference 
		BufferedImage bf = ImageIO.read(new File("bg1.jpg"));
		// adding created component to the JFrame using my backImage class
		setContentPane(new LoginView1(bf));
		 
		//adding other component
		id =new JTextField();
		JLabel label1 = new  JLabel("Username: ");
		label1.setBounds(150, 104, 180, 27);
		add(label1);
		id.setBounds(235, 104, 180, 27);
		add(id);
		JLabel label2 = new JLabel("Password: ");
		label2.setBounds(150, 143,180, 27);
		add(label2);
		passWord = new JTextField();
		passWord.setBounds(235, 143, 180, 27);
		add(passWord);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
	}
	
	public static void main(String[] args) throws IOException {
		new LogInView();
	}

}
