import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class LoginView1 extends JComponent{
	Image img;

	public LoginView1(Image i) throws IOException {
		img = i;
	}
	@Override
	protected void paintComponent(Graphics g) {
		g.drawImage(img, 0, 0, null);
	}
	
	public static void main(String[] args) {
		
	}

}
